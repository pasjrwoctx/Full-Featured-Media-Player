<?php

// Include the player class.
require_once('assets/vendor/autoload.php');

// Create the player.
$player = new FullFeaturedMediaPlayer();

// Get the player's settings.
$settings = get_option('full_featured_media_player_settings');

// Set the player's settings.
$player->setSettings($settings);

// Get the player's HTML.
$html = $player->getHtml();

// Echo the player's HTML.
echo $html;
